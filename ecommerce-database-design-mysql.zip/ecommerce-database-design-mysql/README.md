# E-Commerce Database Design Using MySQL

## Overview

A relational database design for an e-commerce store, implemented in MySQL.

The project currently contains five core tables:

- `customers`
- `products`
- `orders`
- `order_items`
- `payments`

The database is named `SaniShop`.

## Database Relationships

- `customers` → `orders`: one customer can have multiple orders.
- `orders` → `order_items`: one order can contain multiple order items.
- `products` → `order_items`: one product can appear in multiple order items.
- `orders` → `payments`: payments are associated with orders.

## Project Contents

```text
ecommerce-database-design-mysql/
│
├── README.md
├── database/
│   └── schema_and_data.sql
│
├── queries/
│   └── business_queries.sql
│
├── documentation/
│   └── database-overview.md
│
└── screenshots/
```

## Database Schema

### Customers

Stores customer information including name, email, city, and signup date.

### Products

Stores product name, category, price, and available stock.

### Orders

Stores customer orders, order dates, and order status.

### Order Items

Connects orders with products and stores the quantity purchased.

### Payments

Stores payment mode, amount, payment date, and the associated order.

## SQL Analysis Included

The project includes queries for:

1. Total revenue
2. Revenue by product for delivered orders
3. Total amount spent by customer
4. Total quantity sold by product
5. Count of cancelled orders

## How to Run

1. Open MySQL Workbench or another MySQL client.
2. Run `database/schema_and_data.sql`.
3. Select the `SaniShop` database.
4. Run the queries in `queries/business_queries.sql`.

## Technologies

- MySQL
- SQL
- Relational Database Design
- MySQL Workbench

## Scope

This repository reflects the current SQL project as provided. It does not claim additional modules such as sellers, carts, reviews, shipping, or stored procedures because they are not present in the supplied SQL file.
