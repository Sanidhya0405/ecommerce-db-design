# Database Overview

## Tables

| Table | Purpose |
|---|---|
| customers | Customer master data |
| products | Product catalogue and stock |
| orders | Customer order records |
| order_items | Products and quantities belonging to each order |
| payments | Payment information associated with orders |

## Key Constraints

- `customer_id`, `product_id`, `order_id`, `order_item_id`, and `payment_id` use primary keys as defined in the SQL.
- `customers.email` is unique.
- Foreign keys connect orders to customers, order items to orders/products, and payments to orders.

## Included Data

The supplied SQL contains sample customer, product, order, order-item, and payment records.

## Included Analysis

The original SQL contains revenue, product revenue, customer spending, product sales volume, and cancelled-order queries.
